export interface monthlyPlan {
    title?: string;
    price: string;
    badge?: string;
}

export interface yearlyPlan {
    title?: string;
    price: string;
    badge?: string;
}