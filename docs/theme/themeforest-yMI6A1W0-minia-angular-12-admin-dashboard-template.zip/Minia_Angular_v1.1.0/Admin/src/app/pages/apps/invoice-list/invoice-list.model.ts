// Table data
export interface Table {
  invoice_id: string;
  date: string;
  billing_name: string;
  amount: string;
  status: string;
  pdf: string;
  action: string;
}
