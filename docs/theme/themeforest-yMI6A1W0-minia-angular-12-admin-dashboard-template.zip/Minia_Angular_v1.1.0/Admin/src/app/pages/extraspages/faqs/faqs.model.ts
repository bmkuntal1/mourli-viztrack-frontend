export interface faqsModel {
    no: string;
    title: string;
    content: string;
    icon: string;
}
